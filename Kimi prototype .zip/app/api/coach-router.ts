import { z } from "zod";
import { generateObject, generateText } from "ai";
import { TRPCError } from "@trpc/server";
import { createRouter, authedQuery } from "./middleware";
import { kimiGw } from "./ai/provider";
import { classifyAiError, listModels } from "./ai/ai-client";
import { findProfile, findSession, saveSessionFeedback } from "./queries/practice";
import {
  FOCUS_AREAS,
  INSTRUMENTS,
  LEVELS,
  type PlanBlock,
} from "@contracts/practice";

const focusAreaId = z.enum([
  "warmup",
  "technical",
  "record",
  "expression",
  "repertoire",
  "listening",
]);

const planSchema = z.object({
  title: z.string().describe("Short motivating session title, max 8 words"),
  coachNote: z
    .string()
    .describe("One or two sentences of coaching context for this session"),
  blocks: z
    .array(
      z.object({
        title: z.string(),
        minutes: z.number().int().min(1),
        instructions: z
          .string()
          .describe("Concrete, specific instructions — 2 to 4 sentences"),
        tip: z.string().optional().describe("One short pro tip"),
      }),
    )
    .min(2)
    .max(8),
});

type GeneratedPlan = z.infer<typeof planSchema>;

function toTrpcAiError(err: unknown): TRPCError {
  const classified = classifyAiError(err);
  const code =
    classified.name === "AiTransient" ? "TOO_MANY_REQUESTS" : "BAD_GATEWAY";
  return new TRPCError({ code, message: classified.message, cause: classified });
}

async function defaultModel(): Promise<string> {
  const { defaultModelId } = await listModels();
  return defaultModelId;
}

function describeProfile(
  profile: Awaited<ReturnType<typeof findProfile>>,
): string {
  const instrument =
    INSTRUMENTS.find((i) => i.id === profile?.instrument)?.label ??
    "a concert band instrument";
  const level =
    LEVELS.find((l) => l.id === profile?.level)?.label ?? "secondary school";
  return `${instrument} player, ${level} level`;
}

const SYSTEM_PROMPT = `You are LegatoLearn's practice coach for school concert band musicians.
You design structured, timed practice sessions following the LegatoLearn three-level framework:
1. Individual Practice — slow practice systems, isolating passages, metronome discipline, honest self-assessment.
2. Music Making — phrasing, expression, dynamics, communicating through music.
3. Ensemble Skills — listening sideways, blending, section responsibility.

Rules:
- Every block must have concrete, instrument-appropriate instructions a student can follow alone.
- Keep language encouraging, direct, and age-appropriate. No fluff.
- Block minutes must sum exactly to the requested total session length.
- Always include a short warm-up block unless the session is under 20 minutes and focused elsewhere.`;

export const coachRouter = createRouter({
  generatePlan: authedQuery
    .input(
      z.object({
        minutes: z.number().int().min(10).max(180),
        focusAreas: z.array(focusAreaId).min(1).max(6),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const profile = await findProfile(ctx.user.id);
      const focusLabels = input.focusAreas
        .map((id) => FOCUS_AREAS.find((f) => f.id === id)?.label ?? id)
        .join(", ");

      const prompt = `Student: ${describeProfile(profile)}.
Available time: ${input.minutes} minutes total.
Focus areas chosen today: ${focusLabels}.

Design one complete practice session. The block minutes must add up to exactly ${input.minutes}.`;

      let plan: GeneratedPlan;
      try {
        const result = await generateObject({
          model: kimiGw(await defaultModel()),
          schema: planSchema,
          system: SYSTEM_PROMPT,
          prompt,
          providerOptions: { "kimi-gw": { max_completion_tokens: 4096 } },
        });
        plan = result.object;
      } catch (err) {
        throw toTrpcAiError(err);
      }

      // Normalise: force block minutes to sum exactly to the request
      const total = plan.blocks.reduce((s, b) => s + b.minutes, 0);
      if (total !== input.minutes && plan.blocks.length > 0) {
        plan.blocks[plan.blocks.length - 1].minutes += input.minutes - total;
        plan.blocks = plan.blocks.filter((b) => b.minutes > 0);
      }

      return {
        title: plan.title,
        coachNote: plan.coachNote,
        blocks: plan.blocks as PlanBlock[],
      };
    }),

  reflectFeedback: authedQuery
    .input(z.object({ sessionId: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      const session = await findSession(ctx.user.id, input.sessionId);
      if (!session) throw new TRPCError({ code: "NOT_FOUND" });
      if (session.aiFeedback) return { feedback: session.aiFeedback };

      const profile = await findProfile(ctx.user.id);
      const prompt = `A ${describeProfile(profile)} just finished a ${session.plannedMinutes}-minute practice session titled "${session.title}".

Their reflection:
- What clicked: ${session.whatClicked || "(left blank)"}
- What didn't: ${session.whatDidnt || "(left blank)"}
- One thing to carry into tomorrow: ${session.carryForward || "(left blank)"}

Write a short coach's response (3 sentences max): one genuine observation about their reflection, one concrete suggestion for the next session, and end with brief encouragement. No headers, no bullet points, plain prose.`;

      let feedback: string;
      try {
        const result = await generateText({
          model: kimiGw(await defaultModel()),
          system: SYSTEM_PROMPT,
          prompt,
          providerOptions: { "kimi-gw": { max_completion_tokens: 512 } },
        });
        feedback = result.text.trim();
      } catch (err) {
        throw toTrpcAiError(err);
      }

      await saveSessionFeedback(ctx.user.id, session.id, feedback);
      return { feedback };
    }),
});
