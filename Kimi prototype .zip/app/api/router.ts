import { authRouter } from "./auth-router";
import { coachRouter } from "./coach-router";
import { practiceRouter } from "./practice-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  practice: practiceRouter,
  coach: coachRouter,
});

export type AppRouter = typeof appRouter;
