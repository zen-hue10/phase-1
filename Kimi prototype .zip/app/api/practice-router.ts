import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { createRouter, authedQuery } from "./middleware";
import {
  abandonSession,
  completeSession,
  createSession,
  findProfile,
  findSession,
  listSessions,
  practiceStats,
  upsertProfile,
} from "./queries/practice";

const focusAreaId = z.enum([
  "warmup",
  "technical",
  "record",
  "expression",
  "repertoire",
  "listening",
]);

const planBlock = z.object({
  title: z.string().min(1).max(120),
  minutes: z.number().int().min(1).max(120),
  instructions: z.string().min(1).max(2000),
  tip: z.string().max(500).optional(),
});

export const practiceRouter = createRouter({
  profile: authedQuery.query(({ ctx }) => findProfile(ctx.user.id)),

  upsertProfile: authedQuery
    .input(
      z.object({
        instrument: z.string().min(1).max(64),
        level: z.enum(["primary", "secondary", "pre_university", "university"]),
      }),
    )
    .mutation(({ ctx, input }) => upsertProfile(ctx.user.id, input)),

  sessions: authedQuery.query(({ ctx }) => listSessions(ctx.user.id)),

  session: authedQuery
    .input(z.object({ id: z.number().int().positive() }))
    .query(async ({ ctx, input }) => {
      const session = await findSession(ctx.user.id, input.id);
      if (!session) throw new TRPCError({ code: "NOT_FOUND" });
      return session;
    }),

  createSession: authedQuery
    .input(
      z.object({
        title: z.string().min(1).max(255),
        plannedMinutes: z.number().int().min(5).max(240),
        focusAreas: z.array(focusAreaId).min(1).max(6),
        blocks: z.array(planBlock).min(1).max(12),
        source: z.enum(["ai", "classic"]),
        coachNote: z.string().max(2000).nullish(),
      }),
    )
    .mutation(({ ctx, input }) => createSession(ctx.user.id, input)),

  completeSession: authedQuery
    .input(
      z.object({
        id: z.number().int().positive(),
        actualSeconds: z.number().int().min(0).max(24 * 3600),
        whatClicked: z.string().max(2000),
        whatDidnt: z.string().max(2000),
        carryForward: z.string().max(2000),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const { id, ...data } = input;
      const session = await completeSession(ctx.user.id, id, data);
      if (!session) throw new TRPCError({ code: "NOT_FOUND" });
      return session;
    }),

  abandonSession: authedQuery
    .input(z.object({ id: z.number().int().positive() }))
    .mutation(({ ctx, input }) => abandonSession(ctx.user.id, input.id)),

  stats: authedQuery.query(({ ctx }) => practiceStats(ctx.user.id)),
});
