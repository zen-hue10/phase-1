import { and, desc, eq } from "drizzle-orm";
import { getDb } from "./connection";
import { practiceProfiles, practiceSessions } from "@db/schema";
import type { FocusAreaId, LevelId, PlanBlock } from "@contracts/practice";

// ---------- Profile ----------

export function findProfile(userId: number) {
  return getDb().query.practiceProfiles.findFirst({
    where: eq(practiceProfiles.userId, userId),
  });
}

export async function upsertProfile(
  userId: number,
  data: { instrument: string; level: LevelId },
) {
  const existing = await findProfile(userId);
  if (existing) {
    await getDb()
      .update(practiceProfiles)
      .set({ instrument: data.instrument, level: data.level })
      .where(eq(practiceProfiles.userId, userId));
  } else {
    await getDb()
      .insert(practiceProfiles)
      .values({ userId, instrument: data.instrument, level: data.level });
  }
  return findProfile(userId);
}

// ---------- Sessions ----------

export function listSessions(userId: number, limit = 50) {
  return getDb().query.practiceSessions.findMany({
    where: eq(practiceSessions.userId, userId),
    orderBy: [desc(practiceSessions.createdAt)],
    limit,
  });
}

export function findSession(userId: number, sessionId: number) {
  return getDb().query.practiceSessions.findFirst({
    where: and(
      eq(practiceSessions.id, sessionId),
      eq(practiceSessions.userId, userId),
    ),
  });
}

export async function createSession(
  userId: number,
  data: {
    title: string;
    plannedMinutes: number;
    focusAreas: FocusAreaId[];
    blocks: PlanBlock[];
    source: "ai" | "classic";
    coachNote?: string | null;
  },
) {
  const result = await getDb()
    .insert(practiceSessions)
    .values({ userId, ...data });
  const id = Number(result[0].insertId);
  return findSession(userId, id);
}

export async function completeSession(
  userId: number,
  sessionId: number,
  data: {
    actualSeconds: number;
    whatClicked: string;
    whatDidnt: string;
    carryForward: string;
  },
) {
  await getDb()
    .update(practiceSessions)
    .set({ ...data, status: "completed", completedAt: new Date() })
    .where(
      and(
        eq(practiceSessions.id, sessionId),
        eq(practiceSessions.userId, userId),
      ),
    );
  return findSession(userId, sessionId);
}

export async function abandonSession(userId: number, sessionId: number) {
  await getDb()
    .update(practiceSessions)
    .set({ status: "abandoned", completedAt: new Date() })
    .where(
      and(
        eq(practiceSessions.id, sessionId),
        eq(practiceSessions.userId, userId),
        eq(practiceSessions.status, "active"),
      ),
    );
}

export async function saveSessionFeedback(
  userId: number,
  sessionId: number,
  aiFeedback: string,
) {
  await getDb()
    .update(practiceSessions)
    .set({ aiFeedback })
    .where(
      and(
        eq(practiceSessions.id, sessionId),
        eq(practiceSessions.userId, userId),
      ),
    );
}

// ---------- Stats ----------

export async function practiceStats(userId: number) {
  const sessions = await getDb().query.practiceSessions.findMany({
    where: and(
      eq(practiceSessions.userId, userId),
      eq(practiceSessions.status, "completed"),
    ),
    orderBy: [desc(practiceSessions.completedAt)],
    limit: 400,
  });

  const totalMinutes = Math.round(
    sessions.reduce((sum, s) => sum + (s.actualSeconds ?? 0), 0) / 60,
  );

  // Consecutive-day streak ending today or yesterday
  const dayKeys = new Set(
    sessions
      .map((s) => s.completedAt)
      .filter((d): d is Date => !!d)
      .map((d) => {
        const local = new Date(d);
        return `${local.getFullYear()}-${local.getMonth()}-${local.getDate()}`;
      }),
  );
  let streakDays = 0;
  const cursor = new Date();
  const keyOf = (d: Date) => `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
  if (!dayKeys.has(keyOf(cursor))) cursor.setDate(cursor.getDate() - 1);
  while (dayKeys.has(keyOf(cursor))) {
    streakDays += 1;
    cursor.setDate(cursor.getDate() - 1);
  }

  return {
    totalSessions: sessions.length,
    totalMinutes,
    streakDays,
  };
}
